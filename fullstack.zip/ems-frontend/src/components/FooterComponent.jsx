import React from 'react'

const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
<span>Wail alami projet spring boot 2024</span>
        </footer>
      
    </div>
  )
}

export default FooterComponent
